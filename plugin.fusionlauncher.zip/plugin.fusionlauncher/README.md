# FusionKodiPlugin
A Kodi plugin that allows you to launch games.
